package edu.uw.rgm.dao;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

import org.springframework.beans.BeansException;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import edu.uw.ext.framework.account.AccountException;
import edu.uw.ext.framework.account.CreditCard;

/**
 * Class for serializing instances of classes that implement the CreditCard interface. 
 * Implemented using a simple text file, one property per line.
 * @author Odinahon Saydahmedova
 *
 */
public final class CreditCardSer {
	
	private static final String ENCODING = "ISO-8859-1";
	private static final String NULL_STR = "<null>";
	
	private CreditCardSer() {
		
	}
	/**
	 * Reads an CreditCard object from an input stream.
	 * @param in - the input stream to read from
	 * @return the CreditCard object read from stream
	 * @throws edu.uw.ext.framework.account.AccountException - if an error occurs reading from stream or instantiating the object.
	 * @throws UnsupportedEncodingException - if ISO-8859-1 is not supported
	 */
	public final static CreditCard read(final InputStream in) 
			throws edu.uw.ext.framework.account.AccountException, UnsupportedEncodingException{
		final BufferedReader rdr = new BufferedReader(new InputStreamReader(in, ENCODING));
		try (ClassPathXmlApplicationContext appContext = 
				new ClassPathXmlApplicationContext("context.xml")){
			final CreditCard cc = appContext.getBean(CreditCard.class);
			String tmp = null;
			tmp = rdr.readLine();
			cc.setIssuer((NULL_STR.equals(tmp)) ? null :tmp);
			
			tmp = rdr.readLine();
			cc.setType((NULL_STR.equals(tmp)) ? null :tmp);
			
			tmp = rdr.readLine();
			cc.setHolder((NULL_STR.equals(tmp)) ? null :tmp);
			
			tmp = rdr.readLine();
			cc.setAccountNumber((NULL_STR.equals(tmp)) ? null :tmp);
			
			tmp = rdr.readLine();
			cc.setExpirationDate((NULL_STR.equals(tmp)) ? null :tmp);
			return cc;
			
		}catch(final BeansException ex) {
			throw new AccountException("Unable to create credit card instance.", ex);
		}catch(final IOException ex) {
			throw new AccountException("Unable to read persisted credit card data.", ex);
		}
		
		
	}
	/**
	 * Writes an CreditCard object to an output stream.
	 * @param out - the output stream to write to
	 * @param cc - the CreditCard object to write
	 * @throws UnsupportedEncodingException - if ISO-8859-1 is not supported
	 * 
	 */
	public final static void write(final OutputStream out, final CreditCard cc) 
			throws UnsupportedEncodingException{
		
		final PrintWriter wtr  = new PrintWriter(new OutputStreamWriter(out, ENCODING));
		
		if(cc != null) {
			String s;
			s = cc.getIssuer();
			wtr.println(s == null ? NULL_STR :s);
			s = cc.getType();
			wtr.println(s == null ? NULL_STR :s);
			s = cc.getHolder();
			wtr.println(s == null ? NULL_STR :s);
			s = cc.getAccountNumber();
			wtr.println(s == null ? NULL_STR :s);
			s = cc.getExpirationDate();
			wtr.println(s == null ? NULL_STR :s);
			
		}
		wtr.flush();
	}
}
